/*
 * sequence.h
 *
 *  Created on: 26-Sep-2022
 *      Author: akash7071
 */

#ifndef SEQUENCE_H_
#define SEQUENCE_H_

void led_sequence(void);

#endif /* SEQUENCE_H_ */

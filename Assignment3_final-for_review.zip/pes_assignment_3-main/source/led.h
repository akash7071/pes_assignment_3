/*
 * led.h
 *
 *  Created on: 26-Sep-2022
 *      Author: akash7071
 */

#ifndef LED_H_
#define LED_H_


void led_init();
void new_init();
void RED_LED_ON(void);
void BLUE_LED_ON(void);
void GREEN_LED_ON();
void WHITE_LED_ON();
void LEDS_OFF();


#endif /* LED_H_ */

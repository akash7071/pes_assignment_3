/***************************************************************************
 * PES Assignment : Blinkenlights
 * @file   delay.h
 * This file contains the delay function for PES assignment 3.
 * Tools:  MCUXpresso,FRDM-KL25Z dev board
 * Author: Akash Patil
 * Institution: University of Colorado Boulder
 * Mail id: akpa9834@colorado.edu
 **************************************************************************/

#ifndef DELAY_H_
#define DELAY_H_

//Function declarations
void delay(int millis);

//This number of iterations equated to 100ms for me
#define NO_OF_LOOPS 180500


#endif /* DELAY_H_ */


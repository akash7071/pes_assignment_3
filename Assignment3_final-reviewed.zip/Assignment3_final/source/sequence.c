/***************************************************************************
 * PES Assignment : Blinkenlights
 * @file   led.h
 * This file contains the main led_sequence() function for PES assignment 3.
 * Tools:  MCUXpresso,FRDM-KL25Z dev board
 * Author: Akash Patil
 * Institution: University of Colorado Boulder
 * Mail id: akpa9834@colorado.edu
 **************************************************************************/


#include "led.h"
#include "log.h"
#include "delay.h"
#include "tsi.h"

/*Initialise required variables before use*/
int led_color=0;						//0,1,2,3 for white,red,green,blue respectively
int touched=0;							//variable to check if touch even has occured
int touch_value=0;						//value of the TSI module
int count_left=5;						//to keep count of on time delay left in multiples of 100ms
int off_time=5;							//to keep count of off time delay left in multiples of 100ms
int delaySequence[4]={5,10,20,30};		//to cycle on time delay between 500,1000,2000,3000 ms
int index=1;							//index variable used for delaySequence[]


/*enum to keep the change state of control between polling the TSI, updating the LEDs and cycling delay between 500,1000,2000,3000ms */
enum state{
	update,
	poll,
	changeDelay
}next_state;


//---------------------------------------LED sequence infinite loop-------------------------------------------------------
/***********************************************************************************
 * function : Function to poll the touch sensor for input and change the LED state based on those values
 * parameters : none
 * return : none
***********************************************************************************/


void led_sequence()
{
	while(1)
	{
		touch_value=Touch_Scan_LH();
		LOG("-------------------------------------------------- \n");
		LOG(" Positional Data :\n\n", touch_value);
		LOG("-------------------------------------------------- \n");

		switch(next_state)
		{


		//Condition for polling the touch sensor and sampling the data
		case poll:

			if(touch_value<10)
				led_color=0;

			else if(touch_value>10 && touch_value<500)	//boundaries for Red color
			{
				led_color=1;
				touched=1;

			}
			else if(touch_value>500 && touch_value<1000)	//boundaries for GREEN color
			{
				led_color=2;
				touched=1;
			}

			else if(touch_value>1000)			//boundaries for BLUE color
			{
				led_color=3;
				touched=1;
			}


			next_state=update;				//Update next_state to update for updating LED state
			//break;




		/*Update case where the color of the LEDs are changed and delays are called*/
		case update:

			if((led_color==0) && (count_left!=0) && (touched==0))		//white color LED sequence  for 100ms
			{
				WHITE_LED_ON();
				delay(1);
				count_left--;
			}

			else if((led_color==1) && (count_left!=0))			//red color LED sequence  for 100ms
			{
				RED_LED_ON();
				delay(1);
				count_left--;
			}

			else if((led_color==2) && (count_left!=0))		//green color LED sequence  for 100ms
			{
				GREEN_LED_ON();
				delay(1);
				count_left--;
			}

			else if((led_color==3) && (count_left!=0))			//blue color LED sequence for 100ms
			{
				BLUE_LED_ON();
				delay(1);
				count_left--;
			}

			else if (count_left==0)							//If total delay>500ms, change delay sequence
			{

				next_state=changeDelay;
				break;
			}


			next_state=poll;
		//break;
		/*Once first loop with 500ms delay is iterated through, increase sequence to 10ms and so forth*/
		case changeDelay:

			LEDS_OFF();
			delay(1);
			off_time--;										//for 500ms off time
			if(count_left==0 && off_time==0)
			{
				count_left=delaySequence[index++];
				off_time=5;
				if(index>3)
					index=1;								//if index out of bounds, reset to init
				next_state=poll;
				break;
			}
		}

	}

}

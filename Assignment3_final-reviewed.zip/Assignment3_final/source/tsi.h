/***************************************************************************
 * PES Assignment : Blinkenlights
 * @file   tsi.h
 * This file contains the TSI sensor for PES assignment 3.
 * Tools:  MCUXpresso,FRDM-KL25Z dev board,
 * Author: Akash Patil
 * Institution: University of Colorado Boulder
 * Mail id: akpa9834@colorado.edu
 **************************************************************************/

#ifndef TSI_H_
#define TSI_H_

/* Required macros for touch offset and TSI register*/
#define TOUCH_OFFSET 590  // offset value to be subtracted
#define TOUCH_DATA (TSI0->DATA & 0xFFFF)//macro for extracting the count from data register

void Touch_Init();
int Touch_Scan_LH(void);

#endif /* TSI_H_ */

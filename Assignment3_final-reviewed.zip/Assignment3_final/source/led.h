/***************************************************************************
 * PES Assignment : Blinkenlights
 * @file   led.h
 * This file contains the led initialisation function for PES assignment 3.
 * Tools:  MCUXpresso,FRDM-KL25Z dev board
 * Author: Akash Patil
 * Institution: University of Colorado Boulder
 * Mail id: akpa9834@colorado.edu
 **************************************************************************/


#ifndef LED_H_
#define LED_H_


void led_init();
void new_init();
void RED_LED_ON(void);
void BLUE_LED_ON(void);
void GREEN_LED_ON();
void WHITE_LED_ON();
void LEDS_OFF();


#endif /* LED_H_ */

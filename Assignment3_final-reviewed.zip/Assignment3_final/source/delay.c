/***************************************************************************
 * PES Assignment : Blinkenlights
 * @file   delay.c
 * This file contains the delay function of 100ms for PES assignment 3.
 * Tools:  MCUXpresso,FRDM-KL25Z dev board,
 * Author: Akash Patil
 * Institution: University of Colorado Boulder
 * Mail id: akpa9834@colorado.edu
 **************************************************************************/

#include "delay.h"

// ----------------------------------------------Delay------------------------------------------------
/***********************************************************************************
 * @function : while loop to produce the delay. No of iterations are defined
 *              in delay.h
 * parameters : milliseconds in multiples of 100's
 * return : none
***********************************************************************************/
void delay(int millis)
{
    int loops = NO_OF_LOOPS * millis;

    while (loops--)
        ;
}
//--
